import React from "react";
import "./Loder.css"

function Loder() {
  return (
    <div>
      <div className="spinner-container">
        <div className="loading-spinner"></div>
      </div>
    </div>
  );
}

export default Loder;
