import React from "react";

function Andriod() {
  return (
    <div>
      <div className="container-fluid">
      <div className="row">
          <img src="./images/android.jpeg" className="minislide"/>
           </div>
        <div className="row py-5">
          <div className=" subpage">
            <h2 className="text-center text-danger">Android developements</h2>

            <h3 className="text-center">
              Welcome to SpeedUpInfotech Android developements Services
            </h3>

            <h5 className="text-center py-3">
              Android is most popular OS with maximum market share. Let your
              smartphone be intelligent enough to automate your work with our
              applications
            </h5>

            <p>
              Android application development in Cravita Technologies sticks to
              the best in class Android engineering measures and finish
              comprehension of thorough Android ecosystem helping us building
              versatile and practical android applications crosswise over
              android platform like Android mobiles, tablets, android wear, and
              android television. In Cravita technologies, we develop highly
              optimized applications for all iOS platforms like phones, tablets,
              wears, televisions, and mac. In parallel, we focus on simple,
              clean, and intuitive interface so that user is at ease while using
              application.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Andriod;
