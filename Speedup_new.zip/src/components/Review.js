import React from "react";

function Review() {
  return (
    <div className="container-fluid">
      <div className="row position-relative py-2 d-flex flex-column align-items-center">
        <div className="position-relative ourwork-header py-3">
          <div className="ourwork-underline me-5">
            <h6 className="ourwork">Review speedupinfotech</h6>
          </div>
        </div>
        <div className="col-lg-12">
          <h2 className="fs-2 text-white text-center py-2">
            Your Nature Descides Your Future
          </h2>
        </div>
       
      </div>
     
     <div className="row mx-5 my-5">
      <div className="col-lg-6 col-md-6 col-sm-12">
          <iframe
            width="482"
            height="300"
            src="https://www.youtube.com/embed/SlWhtNCqoUw?list=PLfr5N_DIRx0PHiGeuS_k7vtPTuXepMbK5"
            title="Exception Handling in Python with Real Time Example #fortunecloud"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowfullscreen
          ></iframe>
        </div>
        <div className="col-lg-6 col-md-6 col-sm-12">

          <iframe
            width="482"
            height="300"
            src="https://www.youtube.com/embed/SlWhtNCqoUw?list=PLfr5N_DIRx0PHiGeuS_k7vtPTuXepMbK5"
            title="Exception Handling in Python with Real Time Example #fortunecloud"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowfullscreen
          ></iframe>
        </div>
      </div>
     </div>
  );
}

export default Review;
